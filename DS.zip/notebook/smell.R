library(ggplot2)
install.packages("ggplot2")
library(ggplot2)

packageStartupMessage("ggplot2")
install.packages("ggplot2")
library(ggplot2)
library(dplyr)

smell_2018=read.csv("C:/Users/USER/Desktop/smell/smell_2018.csv")
s2018=smell_2018 %>% filter(smell_2018$시군명=="안산시") %>% arrange(측정소명) %>%
  select(시군코드, 시군명, 측정소명, 측정일시각, 아황산가스농도값, 이산화질소농도값)

smell_2017=read.table(file="C:/Users/USER/Desktop/smell/smell_2017.txt", header=TRUE, sep=",")
# sep <- 구분자가 무엇으로 되어있는지 필수적으로 입력해줘야한다.
## 여기서는 구분자가 , 였기 때문에 ,로 입력.
s2017=smell_2017 %>% filter(smell_2017$시군명=="안산시")

smell_2016=read.table("C:/Users/USER/Desktop/smell/smell_2016.txt", header=T, sep=",")
s2016=smell_2016 %>% filter(smell_2016$시군명=="안산시")

str(s2018)
summary(s2018)

spot=read.csv("C:/Users/USER/Desktop/smell/sky_spot.csv", header=T)
spot
auto=read.csv("C:/Users/USER/Desktop/smell/auto_spot.csv", header=T)
auto
